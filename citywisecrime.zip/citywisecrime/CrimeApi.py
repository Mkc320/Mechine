
# coding: utf-8

# In[1]:


import pickle
import json
import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, accuracy_score


# In[2]:


def getJSON(csvFile, index=0):
    import pandas as pd
    df = pd.read_csv(csvFile)
    print(df.iloc[index].to_json())
def dummy_row(df):
    import pandas as pd        
    df2 = pd.DataFrame()
    for k in df:
        df2[k] = [0]
    df2.to_csv("dummy_row.csv", index=False)
    print(df.iloc[0])
def from_dummy_row(user_df):
    import pandas as pd            
    df = pd.read_csv("dummy_row.csv")
    for k in user_df:
        df[k] =user_df[k]
    print(df.info())
    return df
def getDF(d1):
    import pandas as pd            
    d2 = {}
    for k in d1:
        v = []
        v.append(d1[k])
        d2[k]= v       
    return pd.DataFrame(d2)


# In[3]:


def pre_proc(df):
    mAge = df.mean()
    df = df.fillna(mAge)
    df = pd.get_dummies(df)
    return df


# In[4]:


def training():    
    df = pd.read_csv("33_CH_not_murder_victim_age_sex.csv")
    df = pre_proc(df)
    X = df.drop("Victims_Total",axis =1)
    dummy_row(X)
    y=df["Victims_Total"]
    X_train, X_test, y_train, y_test = train_test_split(X,y, train_size=0.8, random_state=11) 
    model = XGBRegressor(n_estimators=100)
    model.fit(X_train, y_train)
    with open("mymodel.pkl", "wb") as f1:
        pickle.dump(model, f1)  
    y_pred = model.predict(X_test)
    err = mean_squared_error(y_test, y_pred)
    print(err)
    print(model.score(X_test, y_test))
    from math import sqrt
    err2 = sqrt(err)
    print(err2)


# In[5]:


# training()


# In[6]:


def pred(jsonData):
#         x = json.loads(jsonData)    
#       df = json_normalize(x) #normalize dont create column for null values
        x= jsonData
        df = getDF(x)
#       tmp = df.iloc[0]
#       tmp.to_csv("tmp2.csv")    
        df = pre_proc(df)
        df = from_dummy_row(df)
        with open("mymodel.pkl", "rb") as f1:
            model = pickle.load(f1)    
        if "Victims_Total" in df:
            df.drop("Victims_Total", inplace=True, axis=1)
        y = model.predict(df)
        print(y)
        return y
    
# pred('{"Area_Name":"Arunachal Pradesh","Year":2001,"Sub_Group_Name":"1. Male Victims","Victims_Above_50_Yrs":1.0,"Victims_Total":6.0,"Victims_Upto_10_15_Yrs":0.0,"Victims_Upto_10_Yrs":0.0,"Victims_Upto_15_18_Yrs":0.0,"Victims_Upto_18_30_Yrs":3.0,"Victims_Upto_30_50_Yrs":2.0}')


# In[7]:


# getJSON("33_CH_not_murder_victim_age_sex.csv", 1)

